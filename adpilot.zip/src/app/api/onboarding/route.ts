import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { createBusiness } from "@/lib/db";
import type { BusinessCategory } from "@/lib/types";

const CATEGORIES: BusinessCategory[] = [
  "Home Services",
  "Retail/Boutique",
  "Fitness/Gym",
  "Professional Services",
  "Other",
];

/** Completes the 2-step wizard: creates the user's first business. */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Please log in first." }, { status: 401 });
  }

  const body = (await request.json().catch(() => null)) as
    | { businessName?: string; category?: string }
    | null;

  const name = body?.businessName?.trim() || "My Business";
  const category: BusinessCategory = CATEGORIES.includes(body?.category as BusinessCategory)
    ? (body?.category as BusinessCategory)
    : "Other";

  const business = await createBusiness({ userId: user.id, name, category });
  return NextResponse.json({ business }, { status: 201 });
}
